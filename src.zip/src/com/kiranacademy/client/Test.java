package com.kiranacademy.client;

import org.hibernate.*;
import org.hibernate.cfg.*;

import com.kiranacademy.enity.*;

public class Test {
	
	public static void main(String[] args) {
		
		Configuration cfg = new Configuration();
		
		cfg.configure("hib.xml").addAnnotatedClass(Employee.class);  
		
		SessionFactory sf = cfg.buildSessionFactory();
		
		
		Session session = sf.openSession();                
		
		
		Employee e=session.get(Employee.class,90);

		System.out.println(e);
		
	}
}
